/*
 * bme680.h
 *
 *  Created on: Jul 5, 2022
 *      Author: kjagu
 */

#ifndef MAIN_BME680_SENSOR_H_
#define MAIN_BME680_SENSOR_H_

/**
 * Starts the BME680 task
 */
void BME680_task_start(void);

#endif /* MAIN_BME680_SENSOR_H_ */
