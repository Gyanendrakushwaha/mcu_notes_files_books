/*
 * tasks_common.h
 *
 *  Created on: Oct 17, 2021
 *      Author: kjagu
 */

#ifndef MAIN_TASKS_COMMON_H_
#define MAIN_TASKS_COMMON_H_

// BME680 Task
#define BME680_TASK_STACK_SIZE				6144
#define BME680_TASK_PRIORITY				3
#define BME680_TASK_CORE_ID					1

#endif /* MAIN_TASKS_COMMON_H_ */
